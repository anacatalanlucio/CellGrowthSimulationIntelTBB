#ifndef CELLGROWTH_H_INCLUDED
#define CELLGROWTH_H_INCLUDED

void initGrid(int, int);
void drawGrid();

#endif // CELLGROWTH_H_INCLUDED

