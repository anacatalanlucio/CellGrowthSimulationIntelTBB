//#include <iostream>
//#include <tbb/tbb.h>
//#include <thread>
//#include <mutex>
//
//  //testing TBB configuration!
//void text_threading_building_blocks() {
//
//	std::mutex mutex;
//	using lock_type = std::lock_guard<std::mutex>;
//	auto callback = [&mutex](auto index) {
//
//		lock_type lock(mutex);
//
//		std::cout << "Thead ID:" << std::this_thread::get_id()
//			<< "  - Index =" << index << std::endl;
//	};
//
//	tbb::parallel_for(1, 10, callback);
//	
//
//}
//
//int main()
//{
//	text_threading_building_blocks();
//	system("pause");
//	return 0;
//};
//
